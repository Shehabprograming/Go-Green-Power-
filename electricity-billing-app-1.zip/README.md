# نظام فواتير الكهرباء — إصدار أولي 0.1

## النشر على الإنترنت باستخدام Vercel
المشروع يستخدم React + Vite. اتبع الخطوات بالترتيب:

1. حمّل ملف ZIP وفك ضغطه على الكمبيوتر.
2. أنشئ مستودعًا جديدًا في GitHub واجعله **Private**، ثم ارفع محتويات المجلد إليه (لا ترفع ملف `.env` إذا أنشأته).
3. افتح Vercel وسجّل الدخول، ثم اختر **Add New → Project** واستورد مستودع GitHub.
4. إعدادات البناء:
   - Framework Preset: Vite
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. في Environment Variables أضف:
   - `VITE_SUPABASE_URL` = `https://ccsocgbyryffglnmfwtd.supabase.co`
   - `VITE_SUPABASE_PUBLISHABLE_KEY` = المفتاح العام **Publishable** من إعدادات مشروع Supabase.
6. اضغط Deploy. بعد اكتمال البناء سيظهر رابط الموقع.
7. في Supabase، افتح Authentication → URL Configuration وأضف رابط الموقع المنشور إلى Site URL وRedirect URLs عند الحاجة.
8. اختبر تسجيل الدخول وإضافة بيانات تجريبية فقط، ولا تدخل بيانات مالية حقيقية قبل اكتمال اختبار الصلاحيات وسير العمل.

## مهم أمنيًا
- لا تضع `service_role` أو أي Secret key في متغير يبدأ بـ `VITE_` أو في أي ملف يرسل للمتصفح.
- اجعل مستودع GitHub خاصًا، ولا ترفع ملف `.env`.
- النشر على الإنترنت لا يعني أن التطبيق جاهز للإنتاج. هذه نسخة أولية تحتاج مراجعة سياسات RLS والصلاحيات والحسابات متعددة العملات وتخصيص الدفعات الجزئية وطباعة PDF واختبارات قبول.
- إذا كنت تعمل من الهاتف فقط، يمكن استخدام GitHub وVercel من المتصفح، لكن رفع الملفات وإعداد المشروع أسهل من الكمبيوتر.

## التشغيل المحلي
1. انسخ `.env.example` إلى `.env`.
2. املأ متغيرات Supabase.
3. شغّل `npm install` ثم `npm run dev`.

